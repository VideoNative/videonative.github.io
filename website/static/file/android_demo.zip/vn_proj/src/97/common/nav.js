var common = require("./common.js");
exports.nav_OnBackClick = function() {
	vn.navigate.navigateBack();
}

exports.copyTo = function(to) {
	return common.copyProperties(this, to);
}
