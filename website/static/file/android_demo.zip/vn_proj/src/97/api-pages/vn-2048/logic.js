var mergeBlock = require('./mergeBlock.js');
var winOrDie = require('./winOrDie.js');

var SMALLEST_SLIDE_DIFF = 50;
var blockList;
var arrayList;
var isHasDead = false;
exports.isWinOrDead = function(){ 
  isDead();
}

function isDead(){
    if(winOrDie.isDie(blockList)){

        console.log("zsj:dead ");

       if(!isHasDead){
            var navigateUrl = "./rankList";
            vn.navigate.navigateTo({
                pageUrl: navigateUrl,
                params: {
                    isGameEnd: 1,
                    finalScore: getCurrentScore()
                }
            });
        }  
        isHasDead = true;
    }else{
        vn.data.update("Score",getCurrentScore());
    } 
}

exports.setBlockList = function(param) {
    blockList = param;
    console.log("zsj:setBlockList called");

    blockList[0].setHidden(false); 

    arrayList = new Array();
    for (var i = 0; i < 4; i++) {

        arrayList[i] = new Array();

        for (var j = 0; j < 4; j++) {
            arrayList[i][j] = null;
        }
    }

    var curX = 0;
    var curY = 0;
    for (var blockItem of blockList) {
        if (curY > 3) {
            curY = 0;
            curX++;
        }
        if (curX > 3) {
            break;
        }
        blockItem.setLine(curX);
        blockItem.setColumn(curY);
        console.log("zsj" + "cur x =  " + curX + " and cury =  " + curY + "getCommNum = " + blockItem.getNumber());
        arrayList[curX][curY] = blockItem;
        curY++;
    }
 
    showRandomBlock();
}

function getUseBlockList() {
    useBlockList = [];
    for (var block of blockList) {
        if (!block.isHidden()) {
            useBlockList.push(block);
        }
    }
    return useBlockList;
}


exports.slide = function(startX, startY, endX, endY) {
    HDiff = endX - startX;
    VDiff = endY - startY;
    if (Math.abs(HDiff) > Math.abs(VDiff)) {
        //横滑
        if (Math.abs(HDiff) < SMALLEST_SLIDE_DIFF) {
            return;
        }
        if (HDiff > 0) {
            var needAdd = mergeBlock.merge(getUseBlockList(), mergeBlock.DIRECTION_RIGHT); 
            moveRight(needAdd);  
            console.log("zsj:rightAction");
        } else {
            var needAdd = mergeBlock.merge(getUseBlockList(), mergeBlock.DIRECTION_LEFT); 
            moveLeft(needAdd);  
            console.log("zsj:leftAction");
        }
    } else {
        //竖滑
        if (Math.abs(VDiff) < SMALLEST_SLIDE_DIFF) {
            return;
        }
        if (VDiff > 0) {
            var needAdd =  mergeBlock.merge(getUseBlockList(), mergeBlock.DIRECTION_DOWN); 
            moveDown(needAdd); 
            console.log("zsj:downAction");
        } else {
            var needAdd = mergeBlock.merge(getUseBlockList(), mergeBlock.DIRECTION_UP);  
            moveUp(needAdd);  
            console.log("zsj:upAction");
        }
    }
  
}

function afterMergeisDead(needAdd){
    if(needAdd){
        isDead();
    }
}

function getCurrentScore(){
    var total = 0;
    for(var item of blockList){
        if(!item.isHidden()){
            total +=  parseInt(item.getNumber());
        }
        
    }

    console.log("js: total =  "+ total);

    return total;
}
 
function moveUp(needFlag){ 
    
    var flag = needFlag;
    var hasMove = false;
 
    for(var y = 0 ; y < 4 ; y ++ ){
        for(var x = 0 ; x < 4 ; x ++){

            for(var x1 = x + 1 ;x1 < 4 ; x1 ++ ){
                if(arrayList[x1][y].isHidden() == false ){
                     //如果为当前为null 说明可以移动
                    if(arrayList[x][y].isHidden() == true){ 

                        arrayList[x1][y].setLine(x,true); 
                        arrayList[x][y].setLine(x1,false);
                        var temp = arrayList[x][y];
                        arrayList[x][y] = arrayList[x1][y];
                        arrayList[x1][y] = temp; 
                        x--; 
                        
                        hasMove = true;
                        flag = true;


                    } else if(arrayList[x][y].getNumber() == arrayList[x1][y].getNumber()){

                        flag == true;
                    }

                    break;
                }
            }
        }
    }

    if(flag){
        console.log("jsand: flag =  "+ flag); 
        showRandomBlock(); 
    }

    if(needFlag && !hasMove){
        console.log("zsj:dead call from move");
        isDead();
    }
}

function moveDown(needFlag) {
 
    var flag = needFlag;
    
    var hasMove = false;
    for(var y = 0 ;y < 4 ; y ++){

        for(var x = 3 ; x >= 0; x --){

            for (var x1 = x - 1; x1 >= 0; x1 --){ 

 
                if(arrayList[x1][y].isHidden() == false ){
                     
                    //如果当前方格为空，说明可以付值
                    if(arrayList[x][y].isHidden() == true ){ 
                 

                        arrayList[x1][y].setLine(x,true); 
                        arrayList[x][y].setLine(x1,false);
                     
                        var temp = arrayList[x][y];
                        arrayList[x][y] = arrayList[x1][y]; 
                        arrayList[x1][y] = temp;
                         
                        flag = true;
                        hasMove = true;
                        x++ ; 
                    } else if(arrayList[x][y].getNumber() == arrayList[x1][y].getNumber()){

                        flag == true;
                    }

                    break;
                }
                
            }
        }
    }

    if(flag){
        console.log("jsand: flag =  "+ flag); 
        showRandomBlock(); 
    }

    if(needFlag && !hasMove){
        console.log("zsj:dead call from move");
        isDead();
    }
}

function moveRight(needFlag){

    var flag = needFlag;

    var hasMove = false;
 
    for(var x = 0 ; x < 4 ; x++){ 

        for(var y = 3 ; y>= 0 ; y--){ 

            for(var y1 = y - 1 ; y1 >= 0 ; y1--){

                if(arrayList[x][y1].isHidden() == false ){ 
                    if(arrayList[x][y].isHidden() == true){ 

                        arrayList[x][y1].setColumn(y,true);
                        arrayList[x][y].setColumn(y1,false);

                        var temp = arrayList[x][y];
                        arrayList[x][y] = arrayList[x][y1];
                        arrayList[x][y1] = temp;

                        y++; 

                        hasMove = true;
                        flag = true;
                    } else if(arrayList[x][y1].getNumber() == arrayList[x][y].getNumber()){

                        flag == true;
                    }
                    break;
                }
            }
        }
    }


    if(flag){
        console.log("jsand: flag =  "+ flag);
        showRandomBlock(); 
    }

    if(needFlag && !hasMove){
        console.log("zsj:dead call from move");
        isDead();
    }

}

function moveLeft(needFlag){
 
    var flag = needFlag;

    var hasMove = false;

    for(var x = 0 ; x < 4; x ++){ 

        for(var y = 0 ; y < 4 ;y ++ ){ 

            for(var y1 = y + 1 ; y1 < 4 ; y1++){ 

                if(arrayList[x][y1].isHidden() == false){
                    if(arrayList[x][y].isHidden() == true){ 

                        arrayList[x][y1].setColumn(y,true);
                        arrayList[x][y].setColumn(y1,false);
                         
                        var temp = arrayList[x][y];
                        arrayList[x][y] = arrayList[x][y1];
                        arrayList[x][y1] = temp;

                        y--; 
                        flag = true;
                        hasMove = true;

                    }else if(arrayList[x][y1].getNumber() == arrayList[x][y].getNumber()){

                        flag == true;
                    }
                    break;
                }
            }
        }
    }

    if(flag){ 
        showRandomBlock(); 
    }

    if(needFlag && !hasMove){
        console.log("zsj:dead call from move");
        isDead();
    }
}


function showRandomBlock(){
    var tempList = [];
    
    for (var i = 0 ; i < 4 ; i ++ ){
        for(var blockItem of arrayList[i]){
            if(blockItem.isHidden()){
                tempList.push(blockItem);
            }
        }
    }

    var target = getRandomInt(tempList.length);
    
    tempList[target].setHidden(false);
    tempList[target].getTextView().setAlpha(0);
 
    tempList[target].getTextView().startAnimation({
        alpha:1.0,
        duration:100,
    });
    //var randomNum = getRandomInt(6);
    tempList[target].setNumber("2");

}

function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}
