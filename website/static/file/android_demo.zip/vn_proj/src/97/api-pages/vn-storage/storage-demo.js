page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },

    onReady: function () {
        vn.storage.getStorage({
            key: "datainfo",
            success: function (data) {
                console.log("Read Cache Data :" + JSON.stringify(data));
                if (data) {
                    vn.data.insert("datainfo", data);
                }
            },
            fail: function (errorCode) {
                console.log("Read Cache Data : fail , errorCode:" + errorCode);
            },
            complete: function () {
                console.log("Read Cache Data : complete");
            }
        });
    },

    onBtnClick: function (param) {
        vn.data.insert("listHidden", "false");
        var info = new Array();
        info.push({ "name": "Line1", "value": 1 });
        info.push({ "name": "Line2", "value": 2 });
        info.push({ "name": "Line3", "value": 3 });
        info.push({ "name": "Line4", "value": 4 });
        info.push({ "name": "Line5", "value": 5 });
        vn.storage.setStorage({
            key: "datainfo",
            data: info,
            success: function () {
                console.log("Write Cache Data :" + JSON.stringify(info));
                vn.data.insert("datainfo", info);
            },
            fail: function (errorCode) {
                console.log("Write Cache Data : fail , errorCode:" + errorCode);
            },
            complete: function () {
                console.log("Write Cache Data : complete");
            }
        });
    },
    onDeleteSorageBtnClick: function () {
        vn.storage.removeStorage({
            key: "datainfo",
            success: function () {
                console.log("Delete Cache Data : success");
                vn.data.insert("datainfo",[]);
            },
            fail: function (errorCode) {
                console.log("Delete Cache Data : fail , errorCode:" + errorCode);
            },
            complete: function () {
                console.log("Delete Cache Data : complete");
            }
        })
    }
})