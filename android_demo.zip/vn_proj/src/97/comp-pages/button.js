page({
	onBackClick: function(param) {
		vn.navigate.navigateBack();
	}
});