function onDataLoadFinish(data) {
    vn.data.insert("rankInfo", data);
}

page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },


    onReady: function (param) {
        console.log("lauchInfo" + JSON.stringify(param));
        vn.data.insert("yourscore", param.finalScore);
        try {
            if (param.isGameEnd == 1) {
                this.showCommitDialog();
                vn.data.insert("isGameEnd", 1);
            } else {
                this.showRankList();
                vn.data.insert("isGameEnd", 0);
            }
        }
        catch (error) {
            console.log(error);
        }

    },

    showRankList: function () {
        vn.data.update("page_title", "排行榜")
        var view = vn.dom.getElementById("rank-container");
        var mainview = vn.dom.getElementById("result-bg");
        mainview.setEnabled(true);
        view.setScaleX(0.5);
        view.setScaleY(0.5);
        view.startAnimation({
            "scale_x": 1.0,
            "scale_y": 1.0,
            "duration": 200
        });
        vn.request.request({
            url: "http://139.129.23.89:8080/getRankList",
            method: "GET",
            success: function (data) {
                console.log("request success");
                console.log(JSON.stringify(data));
                vn.data.update("oriData", JSON.stringify(data))
                onDataLoadFinish(data);
            },
            fail: function (errorcode) {

                console.log("request error");
                console.log(errorcode);
            },
            complete: function () {
                console.log("complete");
            }
        });
    },

    showCommitDialog: function () {
        vn.data.update("page_title", "提交分数")
        var view = vn.dom.getElementById("rank-commit");
        var mainview = vn.dom.getElementById("result-bg");
        mainview.setEnabled(false);
        view.setScaleX(0.5);
        view.setScaleY(0.5);
        view.startAnimation({
            "scale_x": 1.0,
            "scale_y": 1.0,
            "duration": 200
        });
    },

    commitscore: function () {
        this.onBackClick();
//        vn.request.request({
//            url: "http://139.129.23.89:8080/uploadScore",
//            method: "POST",
//            data: {
//                name: vn.data.query("yourname"),
//                score: vn.data.query("yourscore")
//            },
//            success: function (data) {
//                console.log("request success");
//                console.log(JSON.stringify(data));
//                vn.data.update("oriData", JSON.stringify(data))
//                vn.data.insert("isGameEnd", 0);
//                vn.data.update("page_title", "排行榜")
//                var view = vn.dom.getElementById("rank-container");
//                view.setScaleX(0.5);
//                view.setScaleY(0.5);
//                view.startAnimation({
//                    "scale_x": 1.0,
//                    "scale_y": 1.0,
//                    "duration": 200
//                });
//                var mainview = vn.dom.getElementById("main-container");
//                mainview.setEnabled(true);
//                onDataLoadFinish(data);
//            },
//            fail: function (errorcode) {
//
//                console.log("request error");
//                console.log(errorcode);
//            },
//            complete: function () {
//                console.log("complete");
//            }
//        });
    },

    onTextInput: function (params) {
        vn.data.update("yourname",params.event.value);
    },

    TypeError:function(){
        console.log("error");
    }


});