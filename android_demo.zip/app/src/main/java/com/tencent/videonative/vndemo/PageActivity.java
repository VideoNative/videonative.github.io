package com.tencent.videonative.vndemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.widget.FrameLayout;

import com.tencent.videonative.IVNLoadPageCallback;
import com.tencent.videonative.VNPage;
import com.tencent.videonative.VideoNative;
import com.tencent.videonative.js.IJsEngineProxy;

/**
 * 也可以通过VNPage，类似于Fragment的方式，集成到Activity中。
 * 注意：使用这种方式时，需将Activity的生命周期回调到VNPage中，否则js中的页面生命周期回调会不正确
 */
public class PageActivity extends Activity {
	private VNPage mVNPage;
	private View mVNView;
	private ViewGroup mContainerView;
	private boolean mActivityShown;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.page_activity);
		mContainerView = findViewById(R.id.container);
		loadPage();
	}

	@Override
	protected void onResume() {
		super.onResume();
		mActivityShown = true;
		displayPage();
	}

	@Override
	protected void onPause() {
		super.onPause();
		mActivityShown = false;
		displayPage();
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		if (mVNPage != null) {
			mVNPage.onPageReload("{}");
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (mVNPage != null) {
			String result = String.format("{\"result=\"=\"%d\"}", resultCode);
			mVNPage.onPageResult(result);
		}
	}

	@Override
	protected void onDestroy() {
		unloadPage();
		super.onDestroy();
	}

	private void displayPage() {
		if (mVNPage != null) {
			if (mActivityShown) {
				mVNPage.onPageShow();
			} else {
				mVNPage.onPageHide();
			}
		}
	}

	private void loadPage() {
		unloadPage();
		VideoNative.getInstance().loadAppPage("97", "vn://index/index", new IVNLoadPageCallback() {
			@Override
			public void onLoadPageStateChange(String appId, String rootDir, String pageUrl, int state) {
			}

			@Override
			public void onLoadPageFinish(int errorCode, String appId, String rootDir, String pageUrl, VNPage vnPage) {
				if (vnPage != null) {
					if (PageActivity.this.isFinishing()) {
						vnPage.destroy();
						return;
					}

					mVNPage = vnPage;

					//这里注入的JS API会放置到JS的page对象上，在vn页面的js代码中需要通过 this.jsapi.<func> 来调用
					vnPage.addJavascriptInterface(new PageJsApi(vnPage.getJsEngineProxy()),"jsapi");

					mVNView = vnPage.getView(PageActivity.this);

					FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
					mContainerView.addView(mVNView, layoutParams);

					displayPage();
				}
			}
		});
	}

	private void unloadPage() {
		if (mVNPage != null){
			mVNPage.destroy();
			mVNPage = null;
		}

		if (mVNView != null) {
			mContainerView.removeView(mVNView);
			mVNView = null;
		}
	}
}

class PageJsApi {
	PageJsApi(IJsEngineProxy engineProxy) {

	}

	@JavascriptInterface
	public void pageJs() {
		Log.i("PageActivity", "pageJs called()");
	}
}
