page({
	animSubList: function(el, show) {
		var parentEl = el.getParentElement();
		var listEl = parentEl.getElementById("sub-list");
		if (show) {
			listEl.setTranslationY("-100rpx");
			var listAnim = {
				translate_y : 0,
				duration : 150
			}
			listEl.startAnimation(listAnim);
		}
	},

	onMainItemClick: function(param) {
		console.log(JSON.stringify(param));
		var position = param.dataset.position;
		var path = 'component_show_index';
		var showIndex = vn.data.query(path);
		var shown = false;
		if (showIndex == position) {
			vn.data.update(path, -1);
		} else {
			shown = true;
			vn.data.update(path, position);
		}
		this.animSubList(param.target, shown);
	},

	onItemClick: function(param) {
		var navigateUrl = param.dataset.url;
		vn.navigate.navigateTo({pageUrl : navigateUrl});
	}
});