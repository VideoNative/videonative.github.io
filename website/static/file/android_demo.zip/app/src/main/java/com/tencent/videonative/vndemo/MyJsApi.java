package com.tencent.videonative.vndemo;

import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;

import com.eclipsesource.v8.V8;
import com.eclipsesource.v8.V8Function;
import com.eclipsesource.v8.V8Object;
import com.tencent.videonative.js.IJsEngineProxy;
import com.tencent.videonative.js.V8JsPlugin;
import com.tencent.videonative.js.impl.V8JsUtils;

/**
 * 这个类实现了可注入到VN的JS API
 * Created by ashercai on 2018-十一月-21.
 */
public class MyJsApi extends V8JsPlugin {
	private V8Function mCallback;
	private Handler mUiHandler;

	/**
	 * 说明：添加了JavascriptInterface注解的public方法，会被注入到Javascript中
	 * JS API的参数类型可以是基本类型：boolean, int, double, float, String, 也可以是V8Object, V8Array, V8Function。或者直接声明为Object，在使用时再做类型判断
	 * 输入的V8Object, V8Array, V8Function，会在JS API调用结束之后被释放，所以如果你需要在后面在使用这个对象时，需要调用它的twin()来创建一个拷贝，但记得不再使用时调用release()来释放该对象。
	 */

	public MyJsApi(IJsEngineProxy jsEngineProxy) {
		super(jsEngineProxy);
		mUiHandler = new Handler(Looper.getMainLooper());
	}

	@JavascriptInterface
	public String testString(String param) {
		return "====" + param + "====";
	}

	@JavascriptInterface
	public V8Object test2(Object param, V8Function callback) {
		boolean boolParam = V8JsUtils.convert2Boolean(param);
		if (boolParam && callback != null) {
			V8.release(mCallback);
			mCallback = callback.twin();
			mUiHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					if (!mCallback.isReleased() && !mCallback.getRuntime().isReleased()) {
						Object jsResult = mCallback.executeObjectFunction("jsFunction", null);
						V8.release(jsResult);
						V8.release(mCallback);
					}
					mCallback = null;
				}
			}, 1000);
		}

		V8Object result = mIJsEngineProxy.newV8Object();
		result.add("retCode", 1);
		return result;
	}
}
