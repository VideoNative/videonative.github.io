usingcomponents({
	"container" : "container",
	"comp1" : "comp1",
})

page({
});