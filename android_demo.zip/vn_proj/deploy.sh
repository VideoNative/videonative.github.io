#!/bin/bash
java -jar VideoNativePC.jar src output zips
