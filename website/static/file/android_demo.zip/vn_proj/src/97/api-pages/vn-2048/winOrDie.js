exports.isWin = isWin;

exports.isDie = isDie;

function isWin(blockList) {
    for (var block of blockList) {
        if (block.getNumber() >= 2048) {
            return true;
        }
    }
    return false;
}


function isDie(blockList) {
    console.log("winOrDie:begin--------------------------------------------------------------");
    realBlockList = [];
    for (var block of blockList) {
        if (block != null && !block.isHidden() && block.getNumber() != null && block.getNumber().length > 0) {
            realBlockList.push(block);
        }
    }
    console.log("winOrDie: length = " + realBlockList.length);
    if (realBlockList.length < 16) {
        return false;
    }
    for (var block of realBlockList) {
        if (block == null) {
            continue;
        }
        console.log("winOrDie: all block = (" + block.getNumber() + "," + block.getLine() + "," + block.getColumn() + "," + block.isHidden() + "," + block.getY() / 150 + "," + block.getX() / 150 + ")");
    }




    //判断每一行
    var line0 = [null, null, null, null];
    var line1 = [null, null, null, null];
    var line2 = [null, null, null, null];
    var line3 = [null, null, null, null];
    var column0 = [null, null, null, null];
    var column1 = [null, null, null, null];
    var column2 = [null, null, null, null];
    var column3 = [null, null, null, null];
    for (var block of realBlockList) {
        var blockLine = block.getLine();
        var blockColumn = block.getColumn();
        switch (blockLine) {
            case 0:
                line0.splice(blockColumn, 1, block);
                break;
            case 1:
                line1.splice(blockColumn, 1, block);
                break;
            case 2:
                line2.splice(blockColumn, 1, block);
                break;
            case 3:
                line3.splice(blockColumn, 1, block);
                break;
        }
        switch (blockColumn) {
            case 0:
                column0.splice(blockLine, 1, block);
                break;
            case 1:
                column1.splice(blockLine, 1, block);
                break;
            case 2:
                column2.splice(blockLine, 1, block);
                break;
            case 3:
                column3.splice(blockLine, 1, block);
                break;

        }
    }
    var canMerge = lineOrColumnCanMerge(line0) ||
        lineOrColumnCanMerge(line1) ||
        lineOrColumnCanMerge(line2) ||
        lineOrColumnCanMerge(line3) ||
        lineOrColumnCanMerge(column0) ||
        lineOrColumnCanMerge(column1) ||
        lineOrColumnCanMerge(column2) ||
        lineOrColumnCanMerge(column3);
     console.log("winOrDie:end === "+ !canMerge);

    console.log("winOrDie:end--------------------------------------------------------------");
    return !canMerge;
}

function lineOrColumnCanMerge(lineOrColumn) {
    console.log("winOrDie: lineOrColumnList=" + JSON.stringify(lineOrColumn));
    for (var block of lineOrColumn) {
        if (block == null) {
            continue;
        }
        console.log("winOrDie: block = " + JSON.stringify(block) + ",type=" + typeof(block));
        console.log("winOrDie: block = (" + block.getNumber() + "," + block.getLine() + "," + block.getColumn() + "," + block.isHidden() + ")");
    }
    console.log("winOrDie:---------------------");
    var frontBlock = null;
    var backBlock = null;
    for (var block of lineOrColumn) {
        if (block == null) {
            continue;
        }
        if (frontBlock == null) {
            frontBlock = block;
            continue;
        }
        backBlock = block;
        if (frontBlock.getNumber() == backBlock.getNumber()) {
            return true;
        }
        frontBlock = block;
    }
    return false;
}