page(require('../common/nav.js').copyTo({
	onPageChange: function(param) {
    		vn.data.update("curIndex", param.event.pageIndex);
    }
}));