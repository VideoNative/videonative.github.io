function onDataLoadFinish(data) {
    vn.data.insert("weatherinfo", [data["weatherinfo"]]);
}

page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },

    onReady: function () {
        // vn.request.request({
        // url : "http://www.weather.com.cn/data/sk/101280601.html",
        // method:"GET",
        // success:function(data){
        // console.log(data);
        // },
        // fail:function(errorcode){
        // console.log(errorcode);
        // },
        // complete:function(){
        // console.log("complete");
        // }
        // });

    },

    onBtnClick: function () {
        vn.data.delete("weatherinfo");
        vn.data.update("oriData","")
        console.log("start request");
        vn.data.update("sendRequest",0);
        vn.request.request({
            url: "http://www.weather.com.cn/data/sk/101280601.html",
            method: "GET",
            success: function (data) {
                console.log("request success");
                console.log(JSON.stringify(data));
                vn.data.update("oriData",JSON.stringify(data))
                onDataLoadFinish(data);
            },
            fail: function (errorcode) {

                console.log("request error");
                console.log(errorcode);
            },
            complete: function () {
                console.log("complete");
            }
        });
    }


})