#!/bin/bash
java -jar VideoNativePC.jar src output ../app/src/main/assets/vnapp
