var logic = require('./logic.js');

var touchStartX = 0;
var touchStartY = 0;
var touchEndX = 0;
var touchEndY = 0;

var blockList = [];


class Block {
    constructor(textView) {
        this.textView = textView;
    }

    getX() {
        return this.textView.getTranslationX();
    }

    getY() {
        return this.textView.getTranslationY();
    }

    setXY(x, y) {
        this.textView.setTranslationX(x);
        this.textView.setTranslationY(y);
    }

    setX(x) {
        this.textView.setTranslationX(x);


    }

    setY(y) {
        this.textView.setTranslationY(y);
    }

    /**
     * @param {int} lineNumber 从0开始
     */
    setLine(lineNumber, needAnimate) {
        this.textView.setAlpha(1.0);
        if (needAnimate) {
            this.textView.startAnimation({
                translate_y: lineNumber * 150,
                duration:50,
                father:this,
                complete: function() {
                    this.father.setY(lineNumber * 150);
                    console.log("zsj:dead from setLine");
                    logic.isWinOrDead();
                }
            });
        } else {
            this.setY(lineNumber * 150);
        }


    }

    /**
     * @param {int} columnNumber 从0开始
     */
    setColumn(columnNumber, needAnimate) {
        this.textView.setAlpha(1.0);
        if (needAnimate) {
            this.textView.startAnimation({
                translate_x: columnNumber * 150,
                duration:50,
                father:this,
                complete: function() {
                    this.father.setX(columnNumber * 150);
                    console.log("zsj:dead from setColumn");
                    logic.isWinOrDead();
                }
            });
        } else {
            this.setX(columnNumber * 150);
        } 
    }
 



    getLine() {
        return Math.round(this.getY() / 150);
    }

    getColumn() {
        return Math.round(this.getX() / 150);
    }

    setNumber(number) {
        this.textView.setProperty("content", number);
    }

    getNumber() {
        return this.textView.getProperty("content");
    }

    setHidden(isHidden) {
        if (isHidden) {
            this.setNumber(null);
            this.textView.setProperty("hidden", true);
        } else {
            this.textView.setProperty("hidden", false);
        }
    }

    getTextView(){
        return this.textView;
    }

    isHidden() {
        var isHidden = this.textView.getProperty("hidden");
        if (isHidden === "true") {
            return true;
        } else {
            return false;
        }
    }

}

page({

    onBackClick: function(param) {
        vn.navigate.navigateBack();
    },

    onReady:function(){
        if (blockList.length === 0) {
            for (i = 0; i < 16; i++) {
                var textView = vn.dom.getElementById("animateView" + i);
                blockList.push(new Block(textView));
            }
            logic.setBlockList(blockList);
        }
    },

    resetAnimation: function() {
        var animationview = vn.dom.getElementById("animateView");
        vn.dom.getE
        animationview.stopAnimation();
        animationview.setTranslationX(0);
        animationview.setTranslationY(0);
        animationview.setScaleX(1);
        animationview.setScaleY(1);
        animationview.setAlpha(1);
        animationview.setRotation(0);
        animationview.setRotationX(0);
        animationview.setRotationY(0);
        animationview.setProperty("background-color", "#ff7000");
    },

    onBtnClick: function(param) {
        console.log(JSON.stringify(param));
        var idx = param["dataset"]["id"];
        var actionName = vn.data.query("animationList")[idx]["name"];
    },

    touchStart: function(param) {
        touchStartX = param.event.x;
        touchStartY = param.event.y;
        if (blockList.length === 0) {
            for (i = 0; i < 16; i++) {
                var textView = vn.dom.getElementById("animateView" + i);
                blockList.push(new Block(textView));
            }
            logic.setBlockList(blockList);
        }
    },

    touchEnd: function(param) {
        touchEndX = param.event.x;
        touchEndY = param.event.y;
        logic.slide(touchStartX, touchStartY, touchEndX, touchEndY);
    },

    onRankListClick: function(param) {
        console.log("rankListClick");
        var navigateUrl = param.dataset.url;
        vn.navigate.navigateTo({
            pageUrl: navigateUrl,
            params: {
                isGameEnd: param.dataset.isend
            }
        });
    }

});