page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },

    onReady: function () {
        vn.data.insert("listHidden", "false");
        var info = new Array();
        info.push({ "name": "Line1", "value": 1 });
        info.push({ "name": "Line2", "value": 2 });
        info.push({ "name": "Line3", "value": 3 });
        info.push({ "name": "Line4", "value": 4 });
        info.push({ "name": "Line5", "value": 5 });
        vn.data.insert("dataInfo", info);
        console.log(info);
    },

    onBtnClick: function (param) {
        console.log(JSON.stringify(param));
        var id = param["dataset"]["id"];
        vn.data.insert("listHidden", "false");
        if (id == "btn1") {
            var oriData = vn.data.query("dataInfo");
            if (!oriData || oriData == vn.null) {
                console.log("no data");
                oriData = new Array();
                oriData.push({ "name": "Line1", "value": 1 });
                vn.data.insert("dataInfo", oriData);
            } else {
                console.log(JSON.stringify(oriData));
                if (oriData.length == 0) {
                    oriData.push({ "name": "Line" + (oriData.length + 1), "value": 1 });
                } else {
                    //oriData.push({ "name": "Line" + (oriData.length + 1), "value": oriData[oriData.length - 1]["value"] + 1 });
                    var newIndex = oriData.length;
                    vn.data.insert("dataInfo["+newIndex+"]", { "name": "Line" + (oriData.length + 1), "value": oriData[oriData.length - 1]["value"] + 1 });
                }
            }
        } else if (id == "btn2") {
            var oriData = vn.data.query("dataInfo");
            if (oriData) {
                console.log(JSON.stringify(oriData));
                vn.data.delete("dataInfo[0]");
            } else {
                vn.data.insert("listHidden", "true");
            }
        } else if (id == "btn3") {
            vn.data.insert("listHidden", "true");
            var oriData = vn.data.query("dataInfo");
            console.log(JSON.stringify(oriData));
            vn.data.delete("dataInfo", oriData);
        } else if (id == "btn4") {
            var oriData = vn.data.query("dataInfo");
            if (oriData) {
                console.log(JSON.stringify(oriData));
                oriData[oriData.length - 1] = { "name": oriData[oriData.length - 1]["name"], "value": oriData[oriData.length - 1]["value"] + 1 };
                vn.data.update("dataInfo", oriData);
            } else {
                vn.data.insert("listHidden", "true");
            }

        }
    }
});