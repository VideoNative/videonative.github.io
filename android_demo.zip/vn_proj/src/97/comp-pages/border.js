page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },

    onReady: function () {
    },

    doAnimate:function(){
        var view = vn.dom.getElementById("animateview");
        view.startAnimation({
            pivot_x: "50%",
            pivot_y: "50%",
            rotation: 360,
            duration: 600,
            timingFunction: "linear",
            complete:function(){
                view.setRotation(0);
            }
        });
    }

});