component({
	properties : {
		textArray : {
			value : ['原始1', '原始2', '原始3']
		}
	},

	methods : {
		addText : function(input) {
			var arrLen = vn.data.query("textArray.length");
			vn.data.insert("textArray[" + arrLen + "]", input);
		},

		removeText : function() {
        	var arrLen = vn.data.query("textArray.length");
        	vn.data.delete("textArray[0]");
		}
	},

	events : {
		textClick : {}
	},

	viewClick : function() {
		console.log("viewClick");
		console.log("comp1.vn = " + JSON.stringify(vn));
    	console.log("comp1 data = " + JSON.stringify(vn.data.query("")));
	},

	itemClick : function(param) {
		console.log("itemClick = " + JSON.stringify(param));
		this.triggerEvent("textClick", param.dataset.text);
	},

	ready : function() {
		console.log("ready");
		var el = vn.dom.getElementById("inner1");
		console.log("inner1 = " + JSON.stringify(el));
		var el2 = vn.dom.getElementById("outter1");
		console.log("outter1 = " + JSON.stringify(el2));
	}
});