page({
	onBackClick: function(param) {
		vn.navigate.navigateBack();
	},

	onReady: function(param) {
		try {
			if (typeof param.launchParam === 'number') {
				vn.data.update('launchParam', param.launchParam + 1);
			}
		}
		catch(error) {
			console.log(error);
		}
	},

	onRelaunch: function() {
		var v = vn.data.query('relaunch');
		vn.data.update('relaunch', v + 1);
	},

	generateNavObj: function(url) {
		var result = {pageUrl : url};
		result.params = {launchParam:vn.data.query('launchParam')};
		return result;
	},

	openRedirect: function(param) {
		vn.navigate.redirectTo(this.generateNavObj('nav'));
    },

	openNew: function(param) {
    	vn.navigate.navigateTo(this.generateNavObj('nav'));
    },

    openSingle: function(param) {
        vn.navigate.navigateTo(this.generateNavObj('single'));
    },

    relaunch: function(param) {
    	vn.navigate.relaunch(this.generateNavObj('nav'));
    }
});