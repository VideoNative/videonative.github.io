# 开始打包
java -jar VideoNativePC.jar src output

# 完成后复制到项目文件夹（路径自行配置）
cp -R output/* ../../XCode/VideoNativeiOS/Others/Resource/vnapp
