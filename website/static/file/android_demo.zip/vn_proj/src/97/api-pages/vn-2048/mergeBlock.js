var DIRECTION_UP = "direction_up";
var DIRECTION_DOWN = "direction_down";
var DIRECTION_LEFT = "direction_left";
var DIRECTION_RIGHT = "direction_right";

exports.DIRECTION_UP = DIRECTION_UP;
exports.DIRECTION_DOWN = DIRECTION_DOWN;
exports.DIRECTION_LEFT = DIRECTION_LEFT;
exports.DIRECTION_RIGHT = DIRECTION_RIGHT;

exports.merge = function(blockList, direction) {
    console.log("merge:begin----------------------------------------------------");
    for (var block of blockList) {
        if (block == null) {
            continue;
        }
        console.log("merge: all block = (" + block.getNumber() + "," + block.getLine() + "," + block.getColumn() + "," + block.isHidden() + "," + block.getY() / 150 + "," + block.getX() / 150 + ")");
    }



    console.log("merge:1");
    var hasMerged = false;
    if (direction === DIRECTION_LEFT || direction === DIRECTION_RIGHT) {
        console.log("merge:2");
        for (line = 0; line < 4; line++) {
            console.log("merge:3");
            lineBlocks = [null, null, null, null];
            for (var block of blockList) {
                console.log("merge:4");
                if (block.getLine() === line && !block.isHidden() && block.getNumber() != null && block.getNumber().length > 0) {
                    console.log("merge:5");
                    lineBlocks.splice(block.getColumn(), 1, block);
                }
            }
            if (!hasMerged) {
                hasMerged = mergeLineOrColumn(lineBlocks, direction);
            } else {
                mergeLineOrColumn(lineBlocks, direction);
            }

        }
    }

    if (direction === DIRECTION_UP || direction === DIRECTION_DOWN) {
        console.log("merge:6");
        for (colunm = 0; colunm < 4; colunm++) {
            console.log("merge:7");
            columnBlocks = [null, null, null, null];
            for (var block of blockList) {
                console.log("merge:8");
                if (block.getColumn() === colunm && !block.isHidden() && block.getNumber() != null && block.getNumber().length > 0) {
                    console.log("merge:9");
                    columnBlocks.splice(block.getLine(), 1, block);
                }
            }
            if (!hasMerged) {
                hasMerged = mergeLineOrColumn(columnBlocks, direction);
            } else {
                mergeLineOrColumn(columnBlocks, direction);
            }
        }
    }
    console.log("merge:end----------------------------------------------------");
    return hasMerged;
}


function mergeLineOrColumn(lineBlocks, direction) {
    console.log("merge:10");

    console.log("merge:LineOrColumnList=" + JSON.stringify(lineBlocks));
    for (var block of lineBlocks) {
        if (block != null) {
            console.log("merge:LineOrColumnBlock=" + "(" + block.getNumber() + "," + block.getLine() + "," + block.getColumn() + "," + block.isHidden() + "," + block.getY() / 150 + "," + block.getX() / 150 + ")");
        }
    }

    var hasMerged = false;

    var frontBlock = null;
    var backBlock = null;

    var startIndex, endIndex;
    if (direction === DIRECTION_LEFT || direction === DIRECTION_UP) {
        startIndex = 0;
        endIndex = lineBlocks.length - 1;
    } else if (direction === DIRECTION_RIGHT || direction === DIRECTION_DOWN) {
        startIndex = lineBlocks.length - 1;
        endIndex = 0;
    }

    for (i = startIndex; canLoop(startIndex, endIndex, i); startIndex <= endIndex ? i++ : i--) {
        console.log("merge:11");
        if (frontBlock == null) {
            console.log("merge:12");
            frontBlock = lineBlocks[i];
            continue;
        }
        backBlock = lineBlocks[i];
        if (backBlock == null) {
            continue;
        }
        if (frontBlock.getNumber() === backBlock.getNumber()) {
            console.log("merge:13");
            frontBlock.setNumber(frontBlock.getNumber() * 2);
            backBlock.setHidden(true);
            hasMerged = true;
            frontBlock = null;
        } else {
            console.log("merge:14");
            frontBlock = backBlock;
            backBlock = null;
        }


    }
    return hasMerged;
}

function canLoop(startIndex, endIndex, i) {
    if (startIndex < 0 || endIndex < 0) {
        return false;
    }
    if (startIndex <= endIndex) {
        if (i <= endIndex) {
            return true;
        }
    } else {
        if (i >= endIndex) {
            return true;
        }
    }
    return false;
}

function insert(index, item) {
    this.splice(index, 0, item);
};