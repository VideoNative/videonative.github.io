page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },

    resetAnimation: function () {
        var animationview = vn.dom.getElementById("animateView");
        animationview.stopAnimation();
        animationview.setTranslationX(0);
        animationview.setTranslationY(0);
        animationview.setScaleX(1);
        animationview.setScaleY(1);
        animationview.setAlpha(1);
        animationview.setRotation(0);
        animationview.setRotationX(0);
        animationview.setRotationY(0);
        animationview.setProperty("background-color", "#ff7000");
    },

    onBtnClick:function(param){
        this.resetAnimation();
        console.log(JSON.stringify(param));
        var idx = param["dataset"]["id"];
        var animationObj = vn.data.query("animationList")[idx]["animationObj"];
        console.log(JSON.stringify(animationObj));
        var animationview = vn.dom.getElementById("animateView");
        animationview.startAnimation(animationObj);
    }
});