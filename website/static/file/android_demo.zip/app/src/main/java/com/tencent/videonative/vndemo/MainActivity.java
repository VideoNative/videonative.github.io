package com.tencent.videonative.vndemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.tencent.videonative.VideoNative;

public class MainActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_activity);

		Button vnButton = (Button)findViewById(R.id.vn_button);
		vnButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				VideoNative.getInstance().openPage(MainActivity.this, "97", "vn://index/index");
			}
		});

		Button pageButton = (Button)findViewById(R.id.page_button);
		pageButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, PageActivity.class);
				startActivity(intent);
			}
		});
	}
}
