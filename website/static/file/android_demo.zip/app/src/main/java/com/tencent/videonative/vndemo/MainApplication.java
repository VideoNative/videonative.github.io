package com.tencent.videonative.vndemo;

import android.app.Application;

import com.tencent.videonative.VideoNative;
import com.tencent.videonative.dimpl.input.page.VNJcePageInfoBuilder;

/**
 * Created by ashercai on 2018-十一月-20.
 */

public class MainApplication extends Application {
	@Override
	public void onCreate() {
		super.onCreate();
		VideoNative.getInstance()
				.setPageInfoBuilder(new VNJcePageInfoBuilder())
				.setInjector(new MyInjector());
	}
}
