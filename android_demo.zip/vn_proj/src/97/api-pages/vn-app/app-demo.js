page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },

    refereshAppInfo: function () {
        console.log("READ Appinfo");
        var info = new Array();
        info.push({ "name": "getSDKVersionName", "value": vn.app.getSDKVersionName() });
        info.push({ "name": "getSDKVersionCode", "value": vn.app.getSDKVersionCode() });
        info.push({ "name": "getAppVersion", "value": vn.app.getAppVersion() });
        if(vn.app.getShareData("appSession")){
            info.push({ "name": "getSession(\"appSession\")", "value": vn.app.getShareData("appSession")});
        }
        vn.data.update("appinfo", info);
        console.log(info);
    },

    onReady: function () {
        this.refereshAppInfo();
    },

    onSetSession:function(){
        var session = "TEST SESSION";
        vn.app.setShareData("appSession",session);
        this.refereshAppInfo();
    },

    clearSession:function(){
        vn.app.setShareData("appSession",null);
        this.refereshAppInfo();
    },
    
});