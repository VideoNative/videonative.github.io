#! /bin/bash

cd "$(dirname "$0")"

chmod +x mac/DemoForViewsS

./mac/DemoForViewsS

