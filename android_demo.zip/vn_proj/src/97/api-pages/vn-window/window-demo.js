page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },

    refereshScreenInfo: function () {
        console.log("READ SCREENINO");
        var info = new Array();
        info.push({ "name": "getScreenWidth", "value": vn.window.getScreenWidth() });
        info.push({ "name": "getScreenHeight", "value": vn.window.getScreenHeight() });
        info.push({ "name": "getOrientationSetting", "value": vn.window.getOrientationSetting() });
        info.push({ "name": "getCurOrientation", "value": vn.window.getCurOrientation() });
        info.push({ "name": "isDialog", "value": vn.window.isDialog() });
        vn.data.update("ScreenInfo", info);
        console.log(info);
    },

    onReady: function () {
        this.refereshScreenInfo();
    },

    onUnload:function () {
        vn.window.setOrientation("portrait");
    },

    SetOritation: function () {
        vn.window.setOrientation("auto");
        this.refereshScreenInfo();
    },

    SetOritationRight: function () {
        vn.window.setOrientation("landscape");
        this.refereshScreenInfo();
    },

    SetOritationLeft: function () {
        vn.window.setOrientation("reverse-landscape");
        this.refereshScreenInfo();
    },

    SetOritationPortrait: function () {
        vn.window.setOrientation("portrait");
        this.refereshScreenInfo();
    }
});