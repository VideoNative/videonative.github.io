page({

	onBackClick: function (param) {
		vn.navigate.navigateBack();
	},

	onBtnClick: function (param) {
		console.log(JSON.stringify(param));
		var View2 = vn.dom.getElementById("SecondView");
		var id = param["dataset"]["id"];
		if (id == "btn1") {
			switch (this.GetRandomInt(3)) {
				case 0:
					View2.setProperty("background-color", "#2782D8");
					break;
				case 1:
					View2.setProperty("background-color", "#ff0070");
					break;
				case 2:
					View2.setProperty("background-color", "#ff0500");
					break;
				default:
					View2.setProperty("background-color", "#2782D8");
					break;
			}
		} else if (id == "btn2") {
			var View2 = vn.dom.getElementById("SecondView");
			var btn = vn.dom.getElementById("btn3");
			console.log(View2.getProperty("background-color"));
			vn.data.update("viewColor", View2.getProperty("background-color"));
		} else if (id == "btn3") {
			var btn = vn.dom.getElementById("btn4");
			var dataset = btn.getDataSet();
			console.log(JSON.stringify(dataset));
			vn.data.update("dataset", JSON.stringify(dataset));
		} else if (id == "btn4") {
			var position = View2.getPositionRect();
			var info = "[" + position[0] + "," + position[1] + "," + position[2] + "," + position[3] + "]";
			vn.data.update("position", info);
		} else if (id == "btn5") {
			var animation = {
				pivot_x: "50%",
				pivot_y: "50%",
				rotation: 360,
				duration: 600,
				timingFunction: "linear",
				complete: function () {
					View2.setAlpha(1);
					View2.setRotation(0)
				}
			}
			View2.startAnimation(animation);
		}
	},

	loadDomInfo: function () {
		var View2 = vn.dom.getElementById("SecondView");
		var info = new Array;
		info.push({ "name": "getId()", "value": View2.getId() });
		info.push({ "name": "getType()", "value": View2.getType() });
		var myMap = View2.getPropertyKeyList();
		info.push({ "name": "getPropertyKeyList()", "value": myMap.length });
		for (var index in myMap) {
			info.push({ "name": "PropertyKeyList_" + index, "value": myMap[index] });
		}
		var parentView = View2.getParentElement();
		info.push({ "name": "getParentElement()", "value": parentView.getId() });
		var childviews = View2.getChildElements();
		info.push({ "name": "getChildElements()", "value": "childviewCount:" + childviews.length });
		for (var childview in childviews) {
			var view = childviews[childview]
			var tInfo = "";
			tInfo += "Id: " + view.getId();
			tInfo += "  Type: " + view.getType();
			info.push({ "name": "childView_" + childview, "value": tInfo });
		}
		vn.data.update('domInfo', info);
		vn.data.update('shouldShowinfo', 1);
	},

	GetRandomInt: function (max) {
		return Math.floor(Math.random() * Math.floor(max));
	},

	onDomInfoClick: function () {
		this.loadDomInfo();
		vn.data.update("currentTabIndex", 1);
	},

	onOtherClick: function () {
		vn.data.update("currentTabIndex", 0);
	}

});