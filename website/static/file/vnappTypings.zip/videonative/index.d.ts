/** Video Native */
declare namespace vn {

    /**Video Native的Dom对象 */
    declare class dom {
        /**[方法]获取Dom对象 [参数]Dom对象的id，注意id属性必须唯一 [返回]dom对象*/
        static getElementById(id: string): dom
        /**[方法]获取父Dom对象 [返回]Object*/
        getParentElement(): Object
        /**[方法]获取子Dom对象数组 [返回]Array*/
        getChildElements(): Array
        /**[方法]获取Dom对象的Id属性 [返回]String*/
        getId(): String
        /**[方法]获取Dom对象的属性列表 [返回]Array*/
        getClasses(): Array
        /**[方法]获取Dom对象的类型 [返回]String （类型名称如："text"）*/
        getType(): String
        /**[方法]获取Dom对象的属性名称列表 [返回]Array （属性名称列表如：["margin-left","margin-top","background-color"]）*/
        getPropertyKeyList(): Array
        /**[方法]设置节点是否可用 */
        setEnabled(): void
        /**[方法]Dom节点是否可用 [返回]Boolean*/
        isEnabled(): Boolean
        /**[方法]设置Dom对象一些属性 比如：background-color、position [参数]属性名称，值*/
        setProperty(propertyKey: String, propertyValue: String): void
        /**[方法]获取Dom对象的属性值 [参数]属性名称 [返回]属性值String */
        getProperty(propertyKey: String): String
        /**[方法]获取Dom节点的所有data-属性 [返回]有个一属性是data-index=3,则返回为json {"index":3}*/
        getDataSet(): Object
        /**[方法]获取节点相对于父节点的位置属性 [返回]Dom对象位置属性如：[0,0,50.2,50.2] //4个值的顺序是上，右，下，左，单位是 rpx */
        getPositionRect(): Array
        /**[方法]对当前dom对象开启动画 [参数]参数obj对象包含了动画的属性，如动画操作的view属性、动画时长、时间函数、回调函数等属性。*/
        startAnimation(obj: {
            /**num取值范围 0.0 ~ 1.0。 0=完全透明; 1=完全不透明*/
            alpha: Number
            /**取值范围和通用属性background-color相同*/
            background_color: String
            /**在x轴上的旋转角度*/
            rotate_x: Number
            /**在y轴上的旋转角度*/
            rotate_y: Number
            /**表示旋转。和rotate_x、rotate_y不同的是，rotation是围绕pivot点做旋转，而rotate_x是x轴围绕pivot_x旋转，rotate_y围绕pivot_y旋转。 */
            rotation: Number
            /**在x轴上的缩放比例。取值范围 0.0 ~任意正浮点数 */
            scale_x: Number
            /**在y轴上的缩放比例。取值范围 0.0 ~任意正浮点数 */
            scale_y: Number
            /** 在x轴上的偏移。取值范围：负无穷 ~正无穷。类型：rpx, px,% */
            translate_x: Number
            /**在y轴上的偏移。取值范围：负无穷 ~正无穷。类型：rpx, px,% */
            translate_y: Number
            /** 动画延迟开始的时间，毫秒，正整数 */
            delay: Number
            /** 动画的时长，毫秒，正整数 */
            duration: Number
            /**旋转和缩放的中心点x坐标。取值范围：负无穷 ~正无穷。类型：rpx, px,% */
            pivot_x: Number
            /**旋转和缩放的中心点y坐标。取值范围：负无穷 ~正无穷。类型：rpx, px,% */
            pivot_y: Number
            /**表示动画的重复执行次数，整数类型。默认值为0，表示不重复。-1表示无限循环。 */
            repeat_count: Number
            /**回调函数。当动画结束时会回调该方法，没有参数 */
            complete: Function
            /**动画的时间函数。支持下面几种取值 linear ease ease-in ease-out ease-in-out cubic-bezier(x1, y1, x2, y2)*/
            timingFunction: String
        }): void
        /**[方法]停止该dom对象上的所有动画 */
        stopAnimation(): void
        /**[方法]获取当前位置的 x 偏移 [返回] x 偏移，单位 rpx*/
        getTranslationX(): Number
        /**[方法]获取当前位置的 y 偏移 [返回] y 偏移，单位 rpx*/
        getTranslationY(): Number
        /**[方法]设置 x 偏移 [参数] x 偏移，单位 rpx*/
        setTranslationX(x: Number): void
        /**[方法]设置 y 偏移 [参数] y 偏移，单位 rpx*/
        setTranslationY(y: Number): void
        /**[方法]获取 x 轴的缩放比例 [返回] x 轴上的缩放比例*/
        getScaleX(): Number
        /**[方法]获取 y 轴的缩放比例 [返回] y 轴上的缩放比例*/
        getScaleY(): Number
        /**[方法]设置 x 轴的缩放比例 [参数] x 轴的缩放比例*/
        setScaleX(scalex: Number): void
        /**[方法]设置 y 轴的缩放比例 [参数] y 轴的缩放比例*/
        setScaleY(scaley: Number): void
        /**[方法]获取 alpha 值 [返回] alpha 0.0～1.0*/
        getAlpha(): Number
        /**[方法]设置 alpha 值 [参数] alpha 0.0～1.0*/
        setAlpha(alpha: Number): void
        /**[方法]获取当前旋转角度 [返回]旋转角度*/
        getRotation(): Number
        /**[方法]设置旋转的角度 [参数]旋转角度*/
        setRotation(rotation: Number): void
        /**[方法]获取当前x轴旋转角度 [返回]旋转角度*/
        getRotationX(): Number
        /**[方法]设置x轴旋转的角度 [参数]旋转角度*/
        setRotationX(otationx: Number): void
        /**[方法]获取当前y轴旋转角度 [返回]旋转角度*/
        getRotationY(): Number
        /**[方法]设置y轴旋转的角度 [参数]旋转角度*/
        setRotationY(otationy: Number): void
    }

    /** Video Native的Window对象 */
    class window {
        /**[方法]获取屏幕的宽度 [返回]屏幕宽度，单位rpx*/
        static getScreenWidth(): Number
        /**[方法]获取屏幕的高度 [返回]屏幕高度，单位rpx*/
        static getScreenHeight(): Number
        /**[方法]获取屏幕方向设置 [返回]屏幕方向"portrait":竖向，"landscape":横向，"reverse-landscape":逆横向，"auto":根据屏幕位置自动旋转*/
        static getOrientationSetting(): String
        /**[方法]获取当前屏幕方向 [返回]屏幕方向"portrait":竖向，"landscape":横向，"reverse-landscape":逆横向*/
        static getCurOrientation(): Number
        /**[方法]设置屏幕方向，默认为竖屏 [参数]屏幕方向"portrait":竖向，"landscape":横向，"reverse-landscape":逆横向*/
        static setOrientation(orientation: String): void
        /**[方法]当前页面是否为弹框样式 [返回]Boolean 当前页面是否为弹框样式*/
        static isDialog(): Boolean
    }

    /** Video Native的Data对象 */
    class data {
        /**[方法]查询数据 [参数]kayPath（必填） 内存中数据存储的路径 [返回]查询获取的数据*/
        static query(kayPath: String): Object
        /**[方法]插入新数据 [参数]kayPath（必填）内存中数据存储的路径，data新数据 [返回]是否插入成功*/
        static insert(kayPath: String, data: Object): Boolean
        /**[方法]删除数据 [参数]kayPath（必填）内存中数据存储的路径 [返回]是否删除成功*/
        static delete(kayPath: String): Boolean
        /**[方法]更新数据 [参数]kayPath（必填）内存中数据存储的路径，data新数据 [返回]是否更新成功*/
        static update(kayPath: String, data: Object): Boolean
    }

    /** Video Native的Request对象 */
    class request {
        /**[方法]发起数据请求 [参数]requestOrigin:*/
        static request(requestOrigin: {
            /**开发者服务器接口地址 */
            url: String
            /**请求的参数 */
            data: Object | String
            /** 设置请求的 header，header 中不能设置 Referer。*/
            header: Object
            /**（需大写）有效值：OPTIONS, GET(默认), HEAD, POST, PUT, DELETE, TRACE, CONNECT */
            method: String
            /**如果设为json(默认)，会尝试对返回的数据做一次 JSON.parse，有效值：json，text */
            dataType: String
            /**application/json或text/plain */
            requestType: String
            /**收到开发者服务成功返回的回调函数 success返回参数说明:参数:data 类型:Object|String 说明:开发者服务器返回的数据*/
            success: Function
            /** 接口调用失败的回调函数 fail返回参数说明:参数:int 说明:errorCode(0表示成功)*/
            fail: Function
            /**接口调用结束的回调函数（调用成功、失败都会执行），没有参数 */
            complete: Function
        }): void
        /**[方法]取消请求 [參數]要取消的请求id*/
        static cancel(requstId: Number): Boolean
    }
    /** Video Native的storage对象 */
    class storage {
        /**[方法]将数据存储在本地缓存中指定的 key 中，会覆盖掉原来该 key 对应的内容，这是一个异步接口。 */
        static setStorage(object: {
            /**本地缓存中的指定的key*/
            key: String
            /**需要存储的内容*/
            data: Object | String
            /**接口调用成功的回调函数*/
            success: Function
            /**接口调用失败的回调函数*/
            fail: Function
            /**接口调用结束的回调函数（调用成功、失败都会执行），没有参数*/
            complete: Function
            /**存储过期事件*/
            expires: Long
        }): void

        /**[方法]将 data 存储在本地缓存中指定的 key 中，会覆盖掉原来该 key 对应的内容，这是一个同步接口。 [返回]int errorCode(0表示成功)*/
        static setStorageSync(object: {
            /**本地缓存中的指定的key*/
            key: String
            /**需要存储的内容*/
            data: Object | String
            /**存储过期事件*/
            expires: Long
        }): Number

        /**[方法]从本地缓存中异步获取指定 key 对应的内容。*/
        static getStorage(object: {
            /**本地缓存中的指定的key*/
            key: String
            /**接口调用成功的回调函数 success返回参数说明:参数:data 类型:Object/String 说明:key对应的内容*/
            success: Function
            /**接口调用失败的回调函数 fail返回参数说明:类型:int 说明:errorCode(0表示成功)*/
            fail: Function
            /**接口调用结束的回调函数（调用成功、失败都会执行），没有参数*/
            complete: Function
        }): void

        /**[方法]从本地缓存中异步获取指定 key 对应的内容。 [参数]本地缓存中的指定的key [返回]key对应的内容*/
        static getStorageSync(key: String): Object

        /**从本地缓存中异步移除指定 key*/
        static removeStorage(object: {
            /**本地缓存中的指定的key*/
            key: String
            /**接口调用成功的回调函数 success返回参数说明:参数:data 类型:Object/String 说明:key对应的内容*/
            success: Function
            /**接口调用失败的回调函数 fail返回参数说明:类型:int 说明:errorCode(0表示成功)*/
            fail: Function
            /**接口调用结束的回调函数（调用成功、失败都会执行），没有参数*/
            complete: Function
        }): void

        /**[方法]从本地缓存中同步移除指定 key 。  [参数]本地缓存中的指定的key [返回]int	errorCode(0表示成功)*/
        static removeStorageSync(key: String): Number

        /**[方法]清理本地数据缓存。*/
        static clearStorage(): void

        /**[方法]同步清理本地数据缓存。 [返回]int	errorCode(0表示成功)*/
        static clearStorageSync(): Number
    }
    /** Video Native的navigate对象 */
    class navigate {
        /**新页面打开对应的Url。*/
        static clearStorage(object: {
            /**页面Url*/
            pageUrl: String
            /**页面传递的参数*/
            params: String | Object
        }): void

        /**当前页面刷新URL。*/
        static redirectTo(object: {
            /**页面Url*/
            pageUrl: String
            /**页面传递的参数*/
            params: String | Object
        }): void

        /**回退URL*/
        static navigateBack(object: {
            /**回退的页面个数，默认为1 */
            deltaLevel: Number
            /**页面传递的参数*/
            params: String | Object
        }): void

        /**关闭当前APP所有页面，再打开一个新页面。*/
        static relaunch(object: {
            /**页面Url，只能为绝对路径*/
            pageUrl: String
            /**页面传递的参数*/
            params: String | Object
        }): void
    }
    /** Video Native的app对象 */
    class app {
        /**[方法]获取SDK版本名称。 [返回]SDK版本名称如:"1.0.0"*/
        static getSDKVersionName(): String
        /**[方法]获取SDK版本号。  [返回]SDK版本号，从1开始不断增加。如:1*/
        static getSDKVersionCode(): Number
        /**[方法]获取App版本号。 [返回]App版本号，从1开始不断增加。如:1*/
        static getAppVersion(): String
        /**[方法]设置App内共享的数据。 [参数]sessionKey，sessionValue,为null的时候相当于清除sessionValue*/
        static setShareData(key: String, value: Object): void
        /**[方法]过去App内共享的数据。 [参数]sessionKey [返回]返回Session数据。*/
        static getShareData(key: String): Object
    }
    /** Video Native的vn对象 */
    class vn {
        /**从本地缓存中异步移除指定 key*/
        static scanCode(object: {
            /**接口调用成功的回调函数 success返回参数说明:参数:result 类型:String 说明:扫描结果*/
            success: Function
            /**接口调用失败的回调函数 fail返回参数说明:类型:int 说明:errorCode(0表示成功)*/
            fail: Function
            /**接口调用结束的回调函数（调用成功、失败都会执行），没有参数*/
            complete: Function
        }): void
    }

}