page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },

    onReady: function (param) {
        waveAnimation1(vn.dom.getElementById("wave_icon"));
        wave2Animation1(vn.dom.getElementById("static_icon"));
        boatUp(vn.dom.getElementById("boat_icon"));

    },

});


function waveAnimation1(view) {
    view.startAnimation({
        "translate_x": "1100rpx",
        "duration": GetRandomInt(5000),
        "complete": function () {
            waveAnimation2(view);
        }
    });
}

function waveAnimation2(view) {
    view.startAnimation({
        "translate_x": "0",
        "duration": GetRandomInt(5000),
        "complete": function () {
            waveAnimation1(view)
        }
    });
}

function wave2Animation1(view) {
    view.startAnimation({
        "translate_x": "300rpx",
        "duration": GetRandomInt(5000),
        "complete": function () {
            wave2Animation2(view);
        }
    });
}

function wave2Animation2(view) {
    view.startAnimation({
        "translate_x": "0",
        "duration": GetRandomInt(5000),
        "complete": function () {
            wave2Animation1(view)
        }
    });
}

function boatUp(view) {
    view.startAnimation({
        "translate_y": "50rpx",
        "translate_x": "-150rpx", 
        "rotation": GetRandomInt(5)+15,
        "pivot_x": "50%",
        "pivot_y": "50%",
        "duration": 2000,
        "complete": function () {
            boatDown(view)
        }
    });
}

function boatDown(view) {
    view.startAnimation({
        "translate_y": "20rpx",
        "translate_x": "-150rpx",  
        "rotation": -GetRandomInt(5)-15,
        "pivot_x": "50%",
        "pivot_y": "50%",
        "duration": 2000,
        "complete": function () {
            boatUp(view)
        }
    }
    );
}

function GetRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}