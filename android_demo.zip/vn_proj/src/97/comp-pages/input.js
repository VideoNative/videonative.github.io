page({
	onBackClick: function(param) {
		vn.navigate.navigateBack();
	},

	onTextFieldInput: function(params) {
		console.log("onInput:"+params.event.value+" cursor:"+params.event.cursor);
	},

	onTextFieldFocus: function(params) {
		console.log("onFocus:"+params.event.value);
	},

	onTextFieldBlur: function(params) {
		console.log("onBlur:"+params.event.value);
	},

	onTextFieldConfirm: function(params) {
		console.log("onConfirm:"+params.event.value);
		return true;
	},

	onTextAreaInput: function(params) {
		console.log("onInput2:"+params.event.value+" cursor:"+params.event.cursor);
		var hello = params.target.getProperty("content");
		console.log(hello);
	},

	onTextAreaFocus: function(params) {
		console.log("onFocus2:"+params.event.value);
	},

	onTextAreaBlur: function(params) {
		console.log("onBlur2:"+params.event.value);
	},

	onTextAreaConfirm: function(params) {
		console.log("onConfirm2:"+params.event.value);
	}
});