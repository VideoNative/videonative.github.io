package com.tencent.videonative.vndemo;

import com.tencent.videonative.dimpl.injector.DefaultInjector;
import com.tencent.videonative.js.IJsEngineProxy;
import com.tencent.videonative.js.V8JsPlugin;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ashercai on 2018-十一月-20.
 */
public class MyInjector extends DefaultInjector {
	/**
	 * 这个接口用于注册全局JS API。
	 * Map.key 是在JS全局对象中持有这些JS方法的对象名称
	 * V8JsPlugin对象则定义了暴露的方法
	 */
	@Override
	public Map<String, V8JsPlugin> createJSObjectMap(final IJsEngineProxy engineProxy) {
		return new HashMap<String, V8JsPlugin>() {{
			put("abc", new MyJsApi(engineProxy));
		}};
	}
}
