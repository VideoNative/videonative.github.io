component({
	properties : {
		title : {
			type : String,
			value : "Container"
		}
	},

	onBackClick: function(param) {
		vn.navigate.navigateBack();
	}
});