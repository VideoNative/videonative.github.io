page({

    onBackClick: function (param) {
        vn.navigate.navigateBack();
    },

    onReady: function () {
        var animationview = vn.dom.getElementById("mainPlaine");
        animationview.setScaleX(0.5);
        animationview.setScaleY(0.5);
        animationview.startAnimation({
            "scale_x": 1.0,
            "scale_y": 1.0,
            "duration":2000
        });
        var animationview2 = vn.dom.getElementById("animateView2");
        animationview2.startAnimation({
            "rotation": 360,
            "pivot_x": "50%",
            "pivot_y": "50%",
            "repeat_count": -1
        });

        plaineAnimate1( vn.dom.getElementById("mainPlaine"));
        cloudAnimation1(vn.dom.getElementById("cloud0"));
        cloudAnimation1(vn.dom.getElementById("cloud1"));
        cloudAnimation1(vn.dom.getElementById("cloud2"));
        cloudAnimation1(vn.dom.getElementById("cloud3"));
    },

    onBtnClick: function (param) {


    }
});

function plaineAnimate1 (view) {
    view.startAnimation({
        "rotation": GetRandomInt(5)+15,
        "pivot_x": "50%",
        "pivot_y": "50%",
        "scale_x":0.5,
        "scale_y":0.5,
        "translate_x":GetRandomInt(150),
        "translate_y":-GetRandomInt(150),
        "duration":5000,
        "complete": function () {
            plaineAnimate2(view);
        }
    });
}

function plaineAnimate2 (view) {
    view.startAnimation({
        "rotation": -GetRandomInt(5)-15,
        "pivot_x": "50%",
        "pivot_y": "50%",
        "scale_x":1.0,
        "scale_y":1.0,
        "translate_x":-GetRandomInt(150),
        "translate_y":GetRandomInt(150),
        "duration":5000,
        "complete": function () {
            plaineAnimate1(view);
        }
    });
}

function GetRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}

function cloudAnimation1(view){
    view.startAnimation({
        "alpha": GetRandomInt(20)/20,
        "translate_x":GetRandomInt(200),
        "translate_y":GetRandomInt(200),
        "duration":5000,
        "complete": function () {
            cloudAnimation2(view);
        }
    });
}

function cloudAnimation2(view){
    view.startAnimation({
        "alpha": GetRandomInt(20)/20,
        "translate_x":GetRandomInt(200),
        "translate_y":GetRandomInt(200),
        "duration":5000,
        "complete": function () {
            cloudAnimation1(view);
        }
    });
}