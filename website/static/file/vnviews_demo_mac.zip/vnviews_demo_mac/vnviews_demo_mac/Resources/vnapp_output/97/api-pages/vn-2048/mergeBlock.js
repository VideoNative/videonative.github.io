/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./vnapp/97/api-pages/vn-2048/mergeBlock.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./vnapp/97/api-pages/vn-2048/mergeBlock.js":
/*!**************************************************!*\
  !*** ./vnapp/97/api-pages/vn-2048/mergeBlock.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("var DIRECTION_UP = \"direction_up\";\nvar DIRECTION_DOWN = \"direction_down\";\nvar DIRECTION_LEFT = \"direction_left\";\nvar DIRECTION_RIGHT = \"direction_right\";\n\nexports.DIRECTION_UP = DIRECTION_UP;\nexports.DIRECTION_DOWN = DIRECTION_DOWN;\nexports.DIRECTION_LEFT = DIRECTION_LEFT;\nexports.DIRECTION_RIGHT = DIRECTION_RIGHT;\n\nexports.merge = function(blockList, direction) {\n    console.log(\"merge:begin----------------------------------------------------\");\n    for (var block of blockList) {\n        if (block == null) {\n            continue;\n        }\n        console.log(\"merge: all block = (\" + block.getNumber() + \",\" + block.getLine() + \",\" + block.getColumn() + \",\" + block.isHidden() + \",\" + block.getY() / 150 + \",\" + block.getX() / 150 + \")\");\n    }\n\n\n\n    console.log(\"merge:1\");\n    var hasMerged = false;\n    if (direction === DIRECTION_LEFT || direction === DIRECTION_RIGHT) {\n        console.log(\"merge:2\");\n        for (line = 0; line < 4; line++) {\n            console.log(\"merge:3\");\n            lineBlocks = [null, null, null, null];\n            for (var block of blockList) {\n                console.log(\"merge:4\");\n                if (block.getLine() === line && !block.isHidden() && block.getNumber() != null && block.getNumber().length > 0) {\n                    console.log(\"merge:5\");\n                    lineBlocks.splice(block.getColumn(), 1, block);\n                }\n            }\n            if (!hasMerged) {\n                hasMerged = mergeLineOrColumn(lineBlocks, direction);\n            } else {\n                mergeLineOrColumn(lineBlocks, direction);\n            }\n\n        }\n    }\n\n    if (direction === DIRECTION_UP || direction === DIRECTION_DOWN) {\n        console.log(\"merge:6\");\n        for (colunm = 0; colunm < 4; colunm++) {\n            console.log(\"merge:7\");\n            columnBlocks = [null, null, null, null];\n            for (var block of blockList) {\n                console.log(\"merge:8\");\n                if (block.getColumn() === colunm && !block.isHidden() && block.getNumber() != null && block.getNumber().length > 0) {\n                    console.log(\"merge:9\");\n                    columnBlocks.splice(block.getLine(), 1, block);\n                }\n            }\n            if (!hasMerged) {\n                hasMerged = mergeLineOrColumn(columnBlocks, direction);\n            } else {\n                mergeLineOrColumn(columnBlocks, direction);\n            }\n        }\n    }\n    console.log(\"merge:end----------------------------------------------------\");\n    return hasMerged;\n}\n\n\nfunction mergeLineOrColumn(lineBlocks, direction) {\n    console.log(\"merge:10\");\n\n    console.log(\"merge:LineOrColumnList=\" + JSON.stringify(lineBlocks));\n    for (var block of lineBlocks) {\n        if (block != null) {\n            console.log(\"merge:LineOrColumnBlock=\" + \"(\" + block.getNumber() + \",\" + block.getLine() + \",\" + block.getColumn() + \",\" + block.isHidden() + \",\" + block.getY() / 150 + \",\" + block.getX() / 150 + \")\");\n        }\n    }\n\n    var hasMerged = false;\n\n    var frontBlock = null;\n    var backBlock = null;\n\n    var startIndex, endIndex;\n    if (direction === DIRECTION_LEFT || direction === DIRECTION_UP) {\n        startIndex = 0;\n        endIndex = lineBlocks.length - 1;\n    } else if (direction === DIRECTION_RIGHT || direction === DIRECTION_DOWN) {\n        startIndex = lineBlocks.length - 1;\n        endIndex = 0;\n    }\n\n    for (i = startIndex; canLoop(startIndex, endIndex, i); startIndex <= endIndex ? i++ : i--) {\n        console.log(\"merge:11\");\n        if (frontBlock == null) {\n            console.log(\"merge:12\");\n            frontBlock = lineBlocks[i];\n            continue;\n        }\n        backBlock = lineBlocks[i];\n        if (backBlock == null) {\n            continue;\n        }\n        if (frontBlock.getNumber() === backBlock.getNumber()) {\n            console.log(\"merge:13\");\n            frontBlock.setNumber(frontBlock.getNumber() * 2);\n            backBlock.setHidden(true);\n            hasMerged = true;\n            frontBlock = null;\n        } else {\n            console.log(\"merge:14\");\n            frontBlock = backBlock;\n            backBlock = null;\n        }\n\n\n    }\n    return hasMerged;\n}\n\nfunction canLoop(startIndex, endIndex, i) {\n    if (startIndex < 0 || endIndex < 0) {\n        return false;\n    }\n    if (startIndex <= endIndex) {\n        if (i <= endIndex) {\n            return true;\n        }\n    } else {\n        if (i >= endIndex) {\n            return true;\n        }\n    }\n    return false;\n}\n\nfunction insert(index, item) {\n    this.splice(index, 0, item);\n};\n\n//# sourceURL=webpack:///./vnapp/97/api-pages/vn-2048/mergeBlock.js?");

/***/ })

/******/ });