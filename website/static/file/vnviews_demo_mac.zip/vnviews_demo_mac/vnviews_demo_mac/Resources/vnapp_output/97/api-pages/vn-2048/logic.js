/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./vnapp/97/api-pages/vn-2048/logic.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./vnapp/97/api-pages/vn-2048/logic.js":
/*!*********************************************!*\
  !*** ./vnapp/97/api-pages/vn-2048/logic.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var mergeBlock = __webpack_require__(/*! ./mergeBlock.js */ \"./vnapp/97/api-pages/vn-2048/mergeBlock.js\");\nvar winOrDie = __webpack_require__(/*! ./winOrDie.js */ \"./vnapp/97/api-pages/vn-2048/winOrDie.js\");\n\nvar SMALLEST_SLIDE_DIFF = 50;\nvar blockList;\nvar arrayList;\nvar isHasDead = false;\nexports.isWinOrDead = function(){ \n  isDead();\n}\n\nfunction isDead(){\n    if(winOrDie.isDie(blockList)){\n\n        console.log(\"zsj:dead \");\n\n       if(!isHasDead){\n            var navigateUrl = \"./rankList\";\n            vn.navigate.navigateTo({\n                pageUrl: navigateUrl,\n                params: {\n                    isGameEnd: 1,\n                    finalScore: getCurrentScore()\n                }\n            });\n        }  \n        isHasDead = true;\n    }else{\n        vn.data.update(\"Score\",getCurrentScore());\n    } \n}\n\nexports.setBlockList = function(param) {\n    blockList = param;\n    console.log(\"zsj:setBlockList called\");\n\n    blockList[0].setHidden(false); \n\n    arrayList = new Array();\n    for (var i = 0; i < 4; i++) {\n\n        arrayList[i] = new Array();\n\n        for (var j = 0; j < 4; j++) {\n            arrayList[i][j] = null;\n        }\n    }\n\n    var curX = 0;\n    var curY = 0;\n    for (var blockItem of blockList) {\n        if (curY > 3) {\n            curY = 0;\n            curX++;\n        }\n        if (curX > 3) {\n            break;\n        }\n        blockItem.setLine(curX);\n        blockItem.setColumn(curY);\n        console.log(\"zsj\" + \"cur x =  \" + curX + \" and cury =  \" + curY + \"getCommNum = \" + blockItem.getNumber());\n        arrayList[curX][curY] = blockItem;\n        curY++;\n    }\n \n    showRandomBlock();\n}\n\nfunction getUseBlockList() {\n    useBlockList = [];\n    for (var block of blockList) {\n        if (!block.isHidden()) {\n            useBlockList.push(block);\n        }\n    }\n    return useBlockList;\n}\n\n\nexports.slide = function(startX, startY, endX, endY) {\n    HDiff = endX - startX;\n    VDiff = endY - startY;\n    if (Math.abs(HDiff) > Math.abs(VDiff)) {\n        //横滑\n        if (Math.abs(HDiff) < SMALLEST_SLIDE_DIFF) {\n            return;\n        }\n        if (HDiff > 0) {\n            var needAdd = mergeBlock.merge(getUseBlockList(), mergeBlock.DIRECTION_RIGHT); \n            moveRight(needAdd);  \n            console.log(\"zsj:rightAction\");\n        } else {\n            var needAdd = mergeBlock.merge(getUseBlockList(), mergeBlock.DIRECTION_LEFT); \n            moveLeft(needAdd);  \n            console.log(\"zsj:leftAction\");\n        }\n    } else {\n        //竖滑\n        if (Math.abs(VDiff) < SMALLEST_SLIDE_DIFF) {\n            return;\n        }\n        if (VDiff > 0) {\n            var needAdd =  mergeBlock.merge(getUseBlockList(), mergeBlock.DIRECTION_DOWN); \n            moveDown(needAdd); \n            console.log(\"zsj:downAction\");\n        } else {\n            var needAdd = mergeBlock.merge(getUseBlockList(), mergeBlock.DIRECTION_UP);  \n            moveUp(needAdd);  \n            console.log(\"zsj:upAction\");\n        }\n    }\n  \n}\n\nfunction afterMergeisDead(needAdd){\n    if(needAdd){\n        isDead();\n    }\n}\n\nfunction getCurrentScore(){\n    var total = 0;\n    for(var item of blockList){\n        if(!item.isHidden()){\n            total +=  parseInt(item.getNumber());\n        }\n        \n    }\n\n    console.log(\"js: total =  \"+ total);\n\n    return total;\n}\n \nfunction moveUp(needFlag){ \n    \n    var flag = needFlag;\n    var hasMove = false;\n \n    for(var y = 0 ; y < 4 ; y ++ ){\n        for(var x = 0 ; x < 4 ; x ++){\n\n            for(var x1 = x + 1 ;x1 < 4 ; x1 ++ ){\n                if(arrayList[x1][y].isHidden() == false ){\n                     //如果为当前为null 说明可以移动\n                    if(arrayList[x][y].isHidden() == true){ \n\n                        arrayList[x1][y].setLine(x,true); \n                        arrayList[x][y].setLine(x1,false);\n                        var temp = arrayList[x][y];\n                        arrayList[x][y] = arrayList[x1][y];\n                        arrayList[x1][y] = temp; \n                        x--; \n                        \n                        hasMove = true;\n                        flag = true;\n\n\n                    } else if(arrayList[x][y].getNumber() == arrayList[x1][y].getNumber()){\n\n                        flag == true;\n                    }\n\n                    break;\n                }\n            }\n        }\n    }\n\n    if(flag){\n        console.log(\"jsand: flag =  \"+ flag); \n        showRandomBlock(); \n    }\n\n    if(needFlag && !hasMove){\n        console.log(\"zsj:dead call from move\");\n        isDead();\n    }\n}\n\nfunction moveDown(needFlag) {\n \n    var flag = needFlag;\n    \n    var hasMove = false;\n    for(var y = 0 ;y < 4 ; y ++){\n\n        for(var x = 3 ; x >= 0; x --){\n\n            for (var x1 = x - 1; x1 >= 0; x1 --){ \n\n \n                if(arrayList[x1][y].isHidden() == false ){\n                     \n                    //如果当前方格为空，说明可以付值\n                    if(arrayList[x][y].isHidden() == true ){ \n                 \n\n                        arrayList[x1][y].setLine(x,true); \n                        arrayList[x][y].setLine(x1,false);\n                     \n                        var temp = arrayList[x][y];\n                        arrayList[x][y] = arrayList[x1][y]; \n                        arrayList[x1][y] = temp;\n                         \n                        flag = true;\n                        hasMove = true;\n                        x++ ; \n                    } else if(arrayList[x][y].getNumber() == arrayList[x1][y].getNumber()){\n\n                        flag == true;\n                    }\n\n                    break;\n                }\n                \n            }\n        }\n    }\n\n    if(flag){\n        console.log(\"jsand: flag =  \"+ flag); \n        showRandomBlock(); \n    }\n\n    if(needFlag && !hasMove){\n        console.log(\"zsj:dead call from move\");\n        isDead();\n    }\n}\n\nfunction moveRight(needFlag){\n\n    var flag = needFlag;\n\n    var hasMove = false;\n \n    for(var x = 0 ; x < 4 ; x++){ \n\n        for(var y = 3 ; y>= 0 ; y--){ \n\n            for(var y1 = y - 1 ; y1 >= 0 ; y1--){\n\n                if(arrayList[x][y1].isHidden() == false ){ \n                    if(arrayList[x][y].isHidden() == true){ \n\n                        arrayList[x][y1].setColumn(y,true);\n                        arrayList[x][y].setColumn(y1,false);\n\n                        var temp = arrayList[x][y];\n                        arrayList[x][y] = arrayList[x][y1];\n                        arrayList[x][y1] = temp;\n\n                        y++; \n\n                        hasMove = true;\n                        flag = true;\n                    } else if(arrayList[x][y1].getNumber() == arrayList[x][y].getNumber()){\n\n                        flag == true;\n                    }\n                    break;\n                }\n            }\n        }\n    }\n\n\n    if(flag){\n        console.log(\"jsand: flag =  \"+ flag);\n        showRandomBlock(); \n    }\n\n    if(needFlag && !hasMove){\n        console.log(\"zsj:dead call from move\");\n        isDead();\n    }\n\n}\n\nfunction moveLeft(needFlag){\n \n    var flag = needFlag;\n\n    var hasMove = false;\n\n    for(var x = 0 ; x < 4; x ++){ \n\n        for(var y = 0 ; y < 4 ;y ++ ){ \n\n            for(var y1 = y + 1 ; y1 < 4 ; y1++){ \n\n                if(arrayList[x][y1].isHidden() == false){\n                    if(arrayList[x][y].isHidden() == true){ \n\n                        arrayList[x][y1].setColumn(y,true);\n                        arrayList[x][y].setColumn(y1,false);\n                         \n                        var temp = arrayList[x][y];\n                        arrayList[x][y] = arrayList[x][y1];\n                        arrayList[x][y1] = temp;\n\n                        y--; \n                        flag = true;\n                        hasMove = true;\n\n                    }else if(arrayList[x][y1].getNumber() == arrayList[x][y].getNumber()){\n\n                        flag == true;\n                    }\n                    break;\n                }\n            }\n        }\n    }\n\n    if(flag){ \n        showRandomBlock(); \n    }\n\n    if(needFlag && !hasMove){\n        console.log(\"zsj:dead call from move\");\n        isDead();\n    }\n}\n\n\nfunction showRandomBlock(){\n    var tempList = [];\n    \n    for (var i = 0 ; i < 4 ; i ++ ){\n        for(var blockItem of arrayList[i]){\n            if(blockItem.isHidden()){\n                tempList.push(blockItem);\n            }\n        }\n    }\n\n    var target = getRandomInt(tempList.length);\n    \n    tempList[target].setHidden(false);\n    tempList[target].getTextView().setAlpha(0);\n \n    tempList[target].getTextView().startAnimation({\n        alpha:1.0,\n        duration:100,\n    });\n    //var randomNum = getRandomInt(6);\n    tempList[target].setNumber(\"2\");\n\n}\n\nfunction getRandomInt(max) {\n    return Math.floor(Math.random() * Math.floor(max));\n}\n\n\n//# sourceURL=webpack:///./vnapp/97/api-pages/vn-2048/logic.js?");

/***/ }),

/***/ "./vnapp/97/api-pages/vn-2048/mergeBlock.js":
/*!**************************************************!*\
  !*** ./vnapp/97/api-pages/vn-2048/mergeBlock.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("var DIRECTION_UP = \"direction_up\";\nvar DIRECTION_DOWN = \"direction_down\";\nvar DIRECTION_LEFT = \"direction_left\";\nvar DIRECTION_RIGHT = \"direction_right\";\n\nexports.DIRECTION_UP = DIRECTION_UP;\nexports.DIRECTION_DOWN = DIRECTION_DOWN;\nexports.DIRECTION_LEFT = DIRECTION_LEFT;\nexports.DIRECTION_RIGHT = DIRECTION_RIGHT;\n\nexports.merge = function(blockList, direction) {\n    console.log(\"merge:begin----------------------------------------------------\");\n    for (var block of blockList) {\n        if (block == null) {\n            continue;\n        }\n        console.log(\"merge: all block = (\" + block.getNumber() + \",\" + block.getLine() + \",\" + block.getColumn() + \",\" + block.isHidden() + \",\" + block.getY() / 150 + \",\" + block.getX() / 150 + \")\");\n    }\n\n\n\n    console.log(\"merge:1\");\n    var hasMerged = false;\n    if (direction === DIRECTION_LEFT || direction === DIRECTION_RIGHT) {\n        console.log(\"merge:2\");\n        for (line = 0; line < 4; line++) {\n            console.log(\"merge:3\");\n            lineBlocks = [null, null, null, null];\n            for (var block of blockList) {\n                console.log(\"merge:4\");\n                if (block.getLine() === line && !block.isHidden() && block.getNumber() != null && block.getNumber().length > 0) {\n                    console.log(\"merge:5\");\n                    lineBlocks.splice(block.getColumn(), 1, block);\n                }\n            }\n            if (!hasMerged) {\n                hasMerged = mergeLineOrColumn(lineBlocks, direction);\n            } else {\n                mergeLineOrColumn(lineBlocks, direction);\n            }\n\n        }\n    }\n\n    if (direction === DIRECTION_UP || direction === DIRECTION_DOWN) {\n        console.log(\"merge:6\");\n        for (colunm = 0; colunm < 4; colunm++) {\n            console.log(\"merge:7\");\n            columnBlocks = [null, null, null, null];\n            for (var block of blockList) {\n                console.log(\"merge:8\");\n                if (block.getColumn() === colunm && !block.isHidden() && block.getNumber() != null && block.getNumber().length > 0) {\n                    console.log(\"merge:9\");\n                    columnBlocks.splice(block.getLine(), 1, block);\n                }\n            }\n            if (!hasMerged) {\n                hasMerged = mergeLineOrColumn(columnBlocks, direction);\n            } else {\n                mergeLineOrColumn(columnBlocks, direction);\n            }\n        }\n    }\n    console.log(\"merge:end----------------------------------------------------\");\n    return hasMerged;\n}\n\n\nfunction mergeLineOrColumn(lineBlocks, direction) {\n    console.log(\"merge:10\");\n\n    console.log(\"merge:LineOrColumnList=\" + JSON.stringify(lineBlocks));\n    for (var block of lineBlocks) {\n        if (block != null) {\n            console.log(\"merge:LineOrColumnBlock=\" + \"(\" + block.getNumber() + \",\" + block.getLine() + \",\" + block.getColumn() + \",\" + block.isHidden() + \",\" + block.getY() / 150 + \",\" + block.getX() / 150 + \")\");\n        }\n    }\n\n    var hasMerged = false;\n\n    var frontBlock = null;\n    var backBlock = null;\n\n    var startIndex, endIndex;\n    if (direction === DIRECTION_LEFT || direction === DIRECTION_UP) {\n        startIndex = 0;\n        endIndex = lineBlocks.length - 1;\n    } else if (direction === DIRECTION_RIGHT || direction === DIRECTION_DOWN) {\n        startIndex = lineBlocks.length - 1;\n        endIndex = 0;\n    }\n\n    for (i = startIndex; canLoop(startIndex, endIndex, i); startIndex <= endIndex ? i++ : i--) {\n        console.log(\"merge:11\");\n        if (frontBlock == null) {\n            console.log(\"merge:12\");\n            frontBlock = lineBlocks[i];\n            continue;\n        }\n        backBlock = lineBlocks[i];\n        if (backBlock == null) {\n            continue;\n        }\n        if (frontBlock.getNumber() === backBlock.getNumber()) {\n            console.log(\"merge:13\");\n            frontBlock.setNumber(frontBlock.getNumber() * 2);\n            backBlock.setHidden(true);\n            hasMerged = true;\n            frontBlock = null;\n        } else {\n            console.log(\"merge:14\");\n            frontBlock = backBlock;\n            backBlock = null;\n        }\n\n\n    }\n    return hasMerged;\n}\n\nfunction canLoop(startIndex, endIndex, i) {\n    if (startIndex < 0 || endIndex < 0) {\n        return false;\n    }\n    if (startIndex <= endIndex) {\n        if (i <= endIndex) {\n            return true;\n        }\n    } else {\n        if (i >= endIndex) {\n            return true;\n        }\n    }\n    return false;\n}\n\nfunction insert(index, item) {\n    this.splice(index, 0, item);\n};\n\n//# sourceURL=webpack:///./vnapp/97/api-pages/vn-2048/mergeBlock.js?");

/***/ }),

/***/ "./vnapp/97/api-pages/vn-2048/winOrDie.js":
/*!************************************************!*\
  !*** ./vnapp/97/api-pages/vn-2048/winOrDie.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("exports.isWin = isWin;\n\nexports.isDie = isDie;\n\nfunction isWin(blockList) {\n    for (var block of blockList) {\n        if (block.getNumber() >= 2048) {\n            return true;\n        }\n    }\n    return false;\n}\n\n\nfunction isDie(blockList) {\n    console.log(\"winOrDie:begin--------------------------------------------------------------\");\n    realBlockList = [];\n    for (var block of blockList) {\n        if (block != null && !block.isHidden() && block.getNumber() != null && block.getNumber().length > 0) {\n            realBlockList.push(block);\n        }\n    }\n    console.log(\"winOrDie: length = \" + realBlockList.length);\n    if (realBlockList.length < 16) {\n        return false;\n    }\n    for (var block of realBlockList) {\n        if (block == null) {\n            continue;\n        }\n        console.log(\"winOrDie: all block = (\" + block.getNumber() + \",\" + block.getLine() + \",\" + block.getColumn() + \",\" + block.isHidden() + \",\" + block.getY() / 150 + \",\" + block.getX() / 150 + \")\");\n    }\n\n\n\n\n    //判断每一行\n    var line0 = [null, null, null, null];\n    var line1 = [null, null, null, null];\n    var line2 = [null, null, null, null];\n    var line3 = [null, null, null, null];\n    var column0 = [null, null, null, null];\n    var column1 = [null, null, null, null];\n    var column2 = [null, null, null, null];\n    var column3 = [null, null, null, null];\n    for (var block of realBlockList) {\n        var blockLine = block.getLine();\n        var blockColumn = block.getColumn();\n        switch (blockLine) {\n            case 0:\n                line0.splice(blockColumn, 1, block);\n                break;\n            case 1:\n                line1.splice(blockColumn, 1, block);\n                break;\n            case 2:\n                line2.splice(blockColumn, 1, block);\n                break;\n            case 3:\n                line3.splice(blockColumn, 1, block);\n                break;\n        }\n        switch (blockColumn) {\n            case 0:\n                column0.splice(blockLine, 1, block);\n                break;\n            case 1:\n                column1.splice(blockLine, 1, block);\n                break;\n            case 2:\n                column2.splice(blockLine, 1, block);\n                break;\n            case 3:\n                column3.splice(blockLine, 1, block);\n                break;\n\n        }\n    }\n    var canMerge = lineOrColumnCanMerge(line0) ||\n        lineOrColumnCanMerge(line1) ||\n        lineOrColumnCanMerge(line2) ||\n        lineOrColumnCanMerge(line3) ||\n        lineOrColumnCanMerge(column0) ||\n        lineOrColumnCanMerge(column1) ||\n        lineOrColumnCanMerge(column2) ||\n        lineOrColumnCanMerge(column3);\n     console.log(\"winOrDie:end === \"+ !canMerge);\n\n    console.log(\"winOrDie:end--------------------------------------------------------------\");\n    return !canMerge;\n}\n\nfunction lineOrColumnCanMerge(lineOrColumn) {\n    console.log(\"winOrDie: lineOrColumnList=\" + JSON.stringify(lineOrColumn));\n    for (var block of lineOrColumn) {\n        if (block == null) {\n            continue;\n        }\n        console.log(\"winOrDie: block = \" + JSON.stringify(block) + \",type=\" + typeof(block));\n        console.log(\"winOrDie: block = (\" + block.getNumber() + \",\" + block.getLine() + \",\" + block.getColumn() + \",\" + block.isHidden() + \")\");\n    }\n    console.log(\"winOrDie:---------------------\");\n    var frontBlock = null;\n    var backBlock = null;\n    for (var block of lineOrColumn) {\n        if (block == null) {\n            continue;\n        }\n        if (frontBlock == null) {\n            frontBlock = block;\n            continue;\n        }\n        backBlock = block;\n        if (frontBlock.getNumber() == backBlock.getNumber()) {\n            return true;\n        }\n        frontBlock = block;\n    }\n    return false;\n}\n\n//# sourceURL=webpack:///./vnapp/97/api-pages/vn-2048/winOrDie.js?");

/***/ })

/******/ });