# 应用包名
packageName="edu.gemini.tinyplayer"
# 应用文件夹
appfolder="vnapp"

# 开始打包（运行jar可传入3个参数：输入目录、输出目录、输出zip目录）
java -jar VideoNativePC.jar src output ../../AndroidStudio/VideoNativeAndroid/app/src/main/assets/vnapp/

# 同步到手机应用文件夹（路径自行配置）
./adb shell mkdir /sdcard/Android/data/${packageName}/files/${appfolder}
./adb push output /sdcard/Android/data/${packageName}/files/${appfolder}.tmp
./adb shell cp -fR /sdcard/Android/data/${packageName}/files/${appfolder}.tmp/* /sdcard/Android/data/${packageName}/files/${appfolder}
./adb shell rm -rf /sdcard/Android/data/${packageName}/files/${appfolder}.tmp
# ./adb shell am force-stop ${packageName}
