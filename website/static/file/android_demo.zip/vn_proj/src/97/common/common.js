exports.copyProperties = function(from, to) {
	for(var k in from) to[k]=from[k];
	return to;
}