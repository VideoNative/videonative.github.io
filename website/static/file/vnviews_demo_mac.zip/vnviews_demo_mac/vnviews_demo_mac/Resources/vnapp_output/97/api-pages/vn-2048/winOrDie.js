/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./vnapp/97/api-pages/vn-2048/winOrDie.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./vnapp/97/api-pages/vn-2048/winOrDie.js":
/*!************************************************!*\
  !*** ./vnapp/97/api-pages/vn-2048/winOrDie.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("exports.isWin = isWin;\n\nexports.isDie = isDie;\n\nfunction isWin(blockList) {\n    for (var block of blockList) {\n        if (block.getNumber() >= 2048) {\n            return true;\n        }\n    }\n    return false;\n}\n\n\nfunction isDie(blockList) {\n    console.log(\"winOrDie:begin--------------------------------------------------------------\");\n    realBlockList = [];\n    for (var block of blockList) {\n        if (block != null && !block.isHidden() && block.getNumber() != null && block.getNumber().length > 0) {\n            realBlockList.push(block);\n        }\n    }\n    console.log(\"winOrDie: length = \" + realBlockList.length);\n    if (realBlockList.length < 16) {\n        return false;\n    }\n    for (var block of realBlockList) {\n        if (block == null) {\n            continue;\n        }\n        console.log(\"winOrDie: all block = (\" + block.getNumber() + \",\" + block.getLine() + \",\" + block.getColumn() + \",\" + block.isHidden() + \",\" + block.getY() / 150 + \",\" + block.getX() / 150 + \")\");\n    }\n\n\n\n\n    //判断每一行\n    var line0 = [null, null, null, null];\n    var line1 = [null, null, null, null];\n    var line2 = [null, null, null, null];\n    var line3 = [null, null, null, null];\n    var column0 = [null, null, null, null];\n    var column1 = [null, null, null, null];\n    var column2 = [null, null, null, null];\n    var column3 = [null, null, null, null];\n    for (var block of realBlockList) {\n        var blockLine = block.getLine();\n        var blockColumn = block.getColumn();\n        switch (blockLine) {\n            case 0:\n                line0.splice(blockColumn, 1, block);\n                break;\n            case 1:\n                line1.splice(blockColumn, 1, block);\n                break;\n            case 2:\n                line2.splice(blockColumn, 1, block);\n                break;\n            case 3:\n                line3.splice(blockColumn, 1, block);\n                break;\n        }\n        switch (blockColumn) {\n            case 0:\n                column0.splice(blockLine, 1, block);\n                break;\n            case 1:\n                column1.splice(blockLine, 1, block);\n                break;\n            case 2:\n                column2.splice(blockLine, 1, block);\n                break;\n            case 3:\n                column3.splice(blockLine, 1, block);\n                break;\n\n        }\n    }\n    var canMerge = lineOrColumnCanMerge(line0) ||\n        lineOrColumnCanMerge(line1) ||\n        lineOrColumnCanMerge(line2) ||\n        lineOrColumnCanMerge(line3) ||\n        lineOrColumnCanMerge(column0) ||\n        lineOrColumnCanMerge(column1) ||\n        lineOrColumnCanMerge(column2) ||\n        lineOrColumnCanMerge(column3);\n     console.log(\"winOrDie:end === \"+ !canMerge);\n\n    console.log(\"winOrDie:end--------------------------------------------------------------\");\n    return !canMerge;\n}\n\nfunction lineOrColumnCanMerge(lineOrColumn) {\n    console.log(\"winOrDie: lineOrColumnList=\" + JSON.stringify(lineOrColumn));\n    for (var block of lineOrColumn) {\n        if (block == null) {\n            continue;\n        }\n        console.log(\"winOrDie: block = \" + JSON.stringify(block) + \",type=\" + typeof(block));\n        console.log(\"winOrDie: block = (\" + block.getNumber() + \",\" + block.getLine() + \",\" + block.getColumn() + \",\" + block.isHidden() + \")\");\n    }\n    console.log(\"winOrDie:---------------------\");\n    var frontBlock = null;\n    var backBlock = null;\n    for (var block of lineOrColumn) {\n        if (block == null) {\n            continue;\n        }\n        if (frontBlock == null) {\n            frontBlock = block;\n            continue;\n        }\n        backBlock = block;\n        if (frontBlock.getNumber() == backBlock.getNumber()) {\n            return true;\n        }\n        frontBlock = block;\n    }\n    return false;\n}\n\n//# sourceURL=webpack:///./vnapp/97/api-pages/vn-2048/winOrDie.js?");

/***/ })

/******/ });