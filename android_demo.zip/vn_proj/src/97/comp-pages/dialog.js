page({
	close: function(param) {
		vn.navigate.navigateBack();
	}
});